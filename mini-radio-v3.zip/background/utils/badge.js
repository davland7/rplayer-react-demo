export const BADGE_STATES = Object.freeze({
  IDLE: { text: "", color: "#000000" },
  ON: { text: "ON", color: "#28a745" },
  LOADING: { text: "ON", color: "#ffc107" },
  ERROR: { text: "ON", color: "#dc3545" }
});

const AUDIO_TO_BADGE_MAP = Object.freeze({
  playing: "ON",
  loading: "LOADING",
  paused: "IDLE",
  error: "ERROR",
  stopped: "IDLE"
});

/**
 * Update the extension badge based on audio state
 * @param {string} audioState - One of "playing", "loading", "paused", "error", "stopped"
 */
export async function updateBadge(audioState = "stopped") {
  const badgeKey = AUDIO_TO_BADGE_MAP[audioState] || AUDIO_TO_BADGE_MAP.stopped;

  const { text, color } = BADGE_STATES[badgeKey] || BADGE_STATES.IDLE;

  try {
    await chrome.action.setBadgeText({ text });
    await chrome.action.setBadgeBackgroundColor({ color });
  } catch (_error) {}
}
