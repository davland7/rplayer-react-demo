export const BADGE_STATES = Object.freeze({
  CLEAR: { text: "", color: "#000000" },
  ON: { text: "ON", color: "#28a745" },
  LOADING: { text: "ON", color: "#ffc107" },
  ERROR: { text: "ON", color: "#dc3545" }
});

const AUDIO_TO_BADGE_MAP = Object.freeze({
  playing: "ON",
  loading: "LOADING",
  paused: "CLEAR",
  error: "ERROR",
  stopped: "CLEAR"
});

/**
 * @param {string} audioState
 * @returns {Promise<void>}
 */
export async function setBadgeFromAudioState(audioState) {
  const badgeKey = AUDIO_TO_BADGE_MAP[audioState] || "CLEAR";
  await setBadgeState(badgeKey);
}

/**
 * @param {string} badgeKey
 * @returns {Promise<void>}
 */
export async function setBadgeState(badgeKey = "CLEAR") {
  const { text, color } = BADGE_STATES[badgeKey] || BADGE_STATES.CLEAR;

  await chrome.action.setBadgeText({ text });
  await chrome.action.setBadgeBackgroundColor({ color });
}
