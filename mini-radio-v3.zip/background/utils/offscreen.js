import { setBadgeState } from './badge.js';

/**
 * Crate an offscreen document if it doesn't exist
 * @returns {Promise<boolean>} true if created, false if already existed
 */
export async function createOffscreenDocument() {
  const hasDoc = await chrome.offscreen.hasDocument();
  if (!hasDoc) {
    await chrome.offscreen.createDocument({
      url: "offscreen/offscreen.html",
      reasons: [chrome.offscreen.Reason.AUDIO_PLAYBACK],
      justification: "Required for background audio playback to allow continuous streaming of radio stations."
    });
    return true;
  }
  return false;
}

/**
 * Close the offscreen document if it exists
 * @returns {Promise<boolean>} true if closed, false if none existed
 */
export async function closeOffscreenDocument() {
  const hasDoc = await chrome.offscreen.hasDocument();
  if (hasDoc) {
    await chrome.offscreen.closeDocument();
    await setBadgeState();
    return true;
  }
  await setBadgeState();
  return false;
}

/**
 * Check if an offscreen document exists
 * @returns {Promise<boolean>}
 */
export async function hasOffscreenDocument() {
  return chrome.offscreen.hasDocument();
}
