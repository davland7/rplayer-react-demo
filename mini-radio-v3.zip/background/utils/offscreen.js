import { updateBadge } from './badge.js';

/**
 * Crate an offscreen document if it doesn't exist
 * @returns {Promise<boolean>} true if created, false if already existed
 */
export async function createOffscreenDocument() {
  const hasDoc = await chrome.offscreen.hasDocument();
  if (!hasDoc) {
    await chrome.offscreen.createDocument({
      url: "offscreen/offscreen.html",
      reasons: [chrome.offscreen.Reason.AUDIO_PLAYBACK],
      justification: "Required for background audio playback to allow continuous streaming of radio stations."
    });
    return true;
  }
  return false;
}

/**
 * Close the offscreen document if it exists
 * @param {boolean} shouldResetBadge - Whether to reset the badge state
 * @returns {Promise<boolean>} true if closed, false if it didn't exist
 */
export async function closeOffscreenDocument(shouldResetBadge = true) {
  if (shouldResetBadge) await updateBadge();

  const hasDoc =  await hasOffscreenDocument();
  if (hasDoc) {
    try {
      await chrome.offscreen.closeDocument();
      return true;
    } catch (_error) {
      return false;
    }
  }

  return false;
}

/**
 * Check if an offscreen document exists
 * @returns {Promise<boolean>}
 */
export async function hasOffscreenDocument() {
  return chrome.offscreen.hasDocument();
}
