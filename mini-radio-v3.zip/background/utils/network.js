import { WORKER, VALIDATE_STATES } from '../../constants/constant.js';

/**
 * Creates an AbortController with timeout
 * @param {number} ms - Timeout in milliseconds
 * @returns {AbortController}
 */
function createTimeoutController(ms) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), ms);

  // Store timeout ID for cleanup
  controller.timeoutId = timeout;

  return controller;
}

export function buildProxyUrl(url, name) {
  const params = new URLSearchParams({
    url,
    name
  });

  return `${WORKER.URL_BASE}${WORKER.PROXY}?${params.toString()}`;
}

export async function trackStation(name) {
  const controller = createTimeoutController(4000);

  try {
    const body = { stationName: name };

    const response = await fetch(`${WORKER.URL_BASE}${WORKER.TRACK}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(body),
      signal: controller.signal
    });

    if (!response.ok) {
      return null;
    }

    return await response.json();
  } catch (error) {
    console.error('[Network] Track station failed', error);
    return null;
  } finally {
    clearTimeout(controller.timeoutId);
  }
}

export async function validateStream(url) {
  const controller = createTimeoutController(5000);

  try {
    const params = new URLSearchParams({ url });

    const response = await fetch(
      `${WORKER.URL_BASE}${WORKER.VALIDATE}?${params.toString()}`,
      { signal: controller.signal }
    );

    return await response.json();
  } catch (error) {
    const isTimeout = error.name === 'AbortError';

    return {
      state: VALIDATE_STATES.FALLBACK,
      hls: false,
      errorCode: isTimeout ? 'timeout' : 'network_error'
    };
  } finally {
    clearTimeout(controller.timeoutId);
  }
}
