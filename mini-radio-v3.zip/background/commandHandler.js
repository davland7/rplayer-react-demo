import { getVolume, getCurrentStation } from './utils/storage.js';
import { createOffscreenDocument, hasOffscreenDocument } from './utils/offscreen.js';
import { sendMessage } from '../utils/extension.js';
import { ACTIONS } from '../constants/constant.js';

export async function handleCommand(command) {
  if (command === "playpause") {
    try {
      if (await hasOffscreenDocument()) {
        await sendMessage(ACTIONS.OFFSCREEN_TOGGLE);
      } else {
        await createOffscreenDocument();

        const station = await getCurrentStation();
        const volume = await getVolume();

        await sendMessage(ACTIONS.OFFSCREEN_PLAY, { station, volume });
      }
    } catch (error) {
      console.error("[Shortcuts] Play/Pause command failed:", error);
    }
  } else {
    console.warn(`[Shortcuts] Unknown command: ${command}`);
  }
};
