import { closeOffscreenDocument, createOffscreenDocument, hasOffscreenDocument } from './utils/offscreen.js';
import { sendMessage, withErrorHandling } from '../utils/extension.js';
import { ACTIONS, STATES } from '../constants/constant.js';
import { updateBadge } from './utils/badge.js';
import { sendAnalytics, buildProxyUrl, validateStream } from './utils/network.js';
import {
  moveToTopOfHistory,
  resetCustomStation,
  resetHistory,
  resetVolume,
  getCurrentStation,
  getCustomStation,
  getVolume,
  getStations,
  setCustomStation,
  setVolume,
  setCustomStationInHistory
} from './utils/storage.js';

let playLock = Promise.resolve();

async function playStation(station) {
  playLock = playLock.then(() => playStationInternal(station));
  return playLock;
}

async function playStationInternal(station) {
  const { id, hls, src, name } = station;
  const volume = await getVolume();

  if (!await hasOffscreenDocument()) {
    await createOffscreenDocument();
  }

  let stationToPlay = { ...station };

  if (id !== 0) {
    if (hls) {
      sendAnalytics(name);
    } else {
      stationToPlay.src = await buildProxyUrl(src, name);
    }
  }

  await sendMessage(ACTIONS.OFFSCREEN_PLAY, { station: stationToPlay, volume });
  await moveToTopOfHistory(id);
}



async function maybeCloseOffscreenForCustom() {
  const current = await getCurrentStation();
  if (current.id === 0) await closeOffscreenDocument();
}

export function handleMessage(request, sender, sendResponse) {
  const handler = actions[request.action];

  if (handler) {
    return handler({ request, sender, sendResponse });
  }

  return false;
}

export const actions = {
  [ACTIONS.POPUP_GET_DATA]: withErrorHandling(async ({ sendResponse }) => {
    const stations = await getStations();

    let state = STATES.STOPPED;
    if (await hasOffscreenDocument()) {
      state = await sendMessage(ACTIONS.OFFSCREEN_IS_PLAYING) || {};

      // It not normal kill offscreen when loading, so consider it stopped
      if (state === STATES.LOADING) {
        state = STATES.STOPPED;
        await closeOffscreenDocument();
      }
    } else {
      await updateBadge(STATES.STOPPED);
    }

    await sendResponse({ state, stations });
  }),

  [ACTIONS.OPTIONS_GET_DATA]: withErrorHandling(async ({ sendResponse }) => {
    const station = await getCustomStation();
    const volume = await getVolume();

    sendResponse({ station, volume });
  }),

  [ACTIONS.POPUP_PLAY_STREAM]: withErrorHandling(async ({ request, sendResponse }) => {
    const { station } = request;
    await playStation(station);
    sendResponse({ success: true });
  }),

  [ACTIONS.OPTIONS_PLAY_STREAM]: withErrorHandling(async ({ sendResponse }) => {
    const station = await getCustomStation();
    await playStation(station);
    sendResponse({ success: true });
  }),

  [ACTIONS.OPTIONS_SET_CUSTOM_STATION]: withErrorHandling(async ({ request, sendResponse }) => {
    const { station } = request;
    const { src } = await getCustomStation();

    let stationToSave = { ...station };

    if (stationToSave.src && stationToSave.src !== src) {
      const validate = await validateStream(stationToSave.src);

      if (!validate.ok) {
        sendResponse({ success: false, error: validate.error || validate.reason });
        return;
      }

      stationToSave.hls = validate.hls || false;
      stationToSave.src = validate.url || stationToSave.src;

      await maybeCloseOffscreenForCustom();
    }

    await setCustomStation(stationToSave);
    await setCustomStationInHistory();

    sendResponse({ success: true, station: stationToSave });
  }),

  [ACTIONS.OPTIONS_SET_VOLUME]: withErrorHandling(async ({ request, sendResponse }) => {
    const { volume } = request;

    await setVolume(volume);

    if (await hasOffscreenDocument()) {
      await sendMessage(ACTIONS.OFFSCREEN_SET_VOLUME, { volume });
    }

    sendResponse({ success: true });
  }),

  [ACTIONS.OPTIONS_RESET_ITEMS]: withErrorHandling(async ({ request, sendResponse }) => {
    const { items } = request;

    if (items.includes("custom_station") || items.includes("history")) {
      await closeOffscreenDocument();
    }

    const results = {};
    const resetActions = {
      custom_station: resetCustomStation,
      history: resetHistory,
      volume: resetVolume,
    };

    for (const item of items) {
      const action = resetActions[item];

      if (action) {
        results[item] = await action();
      }
    }
    sendResponse({ success: true, results });
  }),
  [ACTIONS.OFFSCREEN_STATE_CHANGED]: withErrorHandling(async ({ request }) => { // Enlève sendResponse ici
    const { state } = request;

    if (state === STATES.ERROR) {
      await updateBadge(STATES.ERROR);
      await closeOffscreenDocument(false);
      return;
    }

    await updateBadge(state);
  })
};
