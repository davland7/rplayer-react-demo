import { ACTIONS, STATES } from '../constants/constant.js';
import { sendMessage, withErrorHandling } from '../utils/extension.js';
import { toDataURL } from '../utils/image.js';
import Hls from './hls.light.min.js';

/** @type {HTMLAudioElement} */
const audio = new Audio();
audio.volume = 0;
audio.preload = 'auto';
audio.crossOrigin = 'anonymous';

/** @type {Hls|null} */
let hlsInstance = null;

// Utility functions
function sendState(status) {
  sendMessage(ACTIONS.OFFSCREEN_STATE_CHANGED, { state: status });
}

function setVolume(volume) {
  audio.volume = volume;
}

async function resolveArtwork(image) {
  if (image.startsWith('data:image/')) {
    return image;
  }
  return await toDataURL(image);
}

// Playback functions
async function togglePlay() {
  try {
    if (audio.paused) {
      await audio.play();
    } else {
      audio.pause();
    }
  } catch (err) {
    console.error('[Offscreen] Toggle play error:', err);
    sendState(STATES.ERROR);
  }
}

async function play(station, volume) {
  const { name, description, image, hls, src } = station;

  if (hlsInstance) {
    hlsInstance.destroy();
    hlsInstance = null;
  }

  setVolume(volume);

  if ('mediaSession' in navigator) {
    try {
      const artworkSrc = await resolveArtwork(image);
      navigator.mediaSession.metadata = new MediaMetadata({
        title: name,
        artist: description,
        artwork: [{ src: artworkSrc, sizes: '192x192', type: 'image/webp' }]
      });

      navigator.mediaSession.setActionHandler('play', async () => {
        try {
          if (audio.paused) {
            await audio.play();
          }
        } catch (err) {
          console.error('[Offscreen] MediaSession play error:', err);
          sendState(STATES.ERROR);
        }
      });
      navigator.mediaSession.setActionHandler('pause', () => {
        if (!audio.paused) {
          audio.pause();
        }
      });

    } catch (err) {
      console.warn('[Offscreen] MediaSession error:', err);
    }
  }

  if (hls) {
    if (Hls.isSupported()) {
      hlsInstance = new Hls();
      hlsInstance.attachMedia(audio);
      hlsInstance.on(Hls.Events.MEDIA_ATTACHED, () => {
        hlsInstance.loadSource(src);
      });
      hlsInstance.on(Hls.Events.ERROR, (_event, data) => {
        console.error('[Offscreen] HLS.js error:', data);
        sendState(STATES.ERROR);
      });
    } else {
      audio.src = src;
      audio.load();
    }
  } else {
    audio.src = src;
    audio.load();
  }

  try {
    await audio.play();
  } catch (err) {
    console.warn('play() rejected', err);
  }
}

// Audio event listeners
audio.addEventListener('loadstart', () => sendState(STATES.LOADING));
audio.addEventListener('waiting', () => {
  if (!audio.paused) return; // Don't show loading if already playing
  sendState(STATES.LOADING);
});
audio.addEventListener('playing', () => sendState(STATES.PLAYING));
audio.addEventListener('pause', () => sendState(STATES.PAUSED));
audio.addEventListener('ended', () => sendState(STATES.PAUSED));
audio.addEventListener('error', (event) => {
  // HLS errors are handled by HLS.Events.ERROR
  if (hlsInstance) return;
  console.error('[Offscreen] Audio element error (NATIVE):', event);
  sendState(STATES.ERROR);
});

// Message handlers
const actions = {
  [ACTIONS.OFFSCREEN_PLAY]: withErrorHandling(async ({ request, sendResponse }) => {
    const { station, volume } = request;
    await play(station, volume);
    sendResponse({ success: true });
  }),

  [ACTIONS.OFFSCREEN_TOGGLE]: withErrorHandling(async ({ sendResponse }) => {
    await togglePlay();
    sendResponse({ success: true });
  }),

  [ACTIONS.OFFSCREEN_SET_VOLUME]: withErrorHandling(async ({ request, sendResponse }) => {
    const { volume } = request;

    setVolume(volume);
    sendResponse({ success: true });
  }),

  [ACTIONS.OFFSCREEN_IS_PLAYING]: withErrorHandling(async ({ sendResponse }) => {
    const state = !audio.paused ? STATES.PLAYING : STATES.PAUSED;
    sendResponse(state);
  })
};

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  const handler = actions[request.action];
  if (handler) {
    handler({ request, sender, sendResponse });
    return true;
  }
  return false;
});
