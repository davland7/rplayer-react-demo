/**
 * Returns the simplified language code (fr/en)
 * @returns {string}
 */
export function getLangCode() {
  const lang = chrome.i18n.getUILanguage();
  return lang.startsWith('fr') ? 'fr' : 'en';
}

/**
 * Gets a translated message from _locales
 * @param {string} key - Message key
 * @param {Array<string>} substitutions - Values to insert
 * @returns {string}
 */
export function t(key, substitutions = []) {
  return chrome.i18n.getMessage(key, substitutions);
}
