/**
 * Converts an image file to base64 resized (default 256x256).
 * Used for files chosen via <input type="file">.
 * @param {File} file - Image file
 * @param {number} size - Target size (default 256)
 * @returns {Promise<string>} - Data URL in WebP
 */
export function fileToBase64(file, size = 256) {
  return new Promise((resolve, reject) => {
    const image = new Image();
    const reader = new FileReader();

    reader.onload = (event) => {
      image.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');

        canvas.width = size;
        canvas.height = size;

        const scale = Math.min(size / image.width, size / image.height);
        const newWidth = image.width * scale;
        const newHeight = image.height * scale;
        const offsetX = (size - newWidth) / 2;
        const offsetY = (size - newHeight) / 2;

        ctx.clearRect(0, 0, size, size);
        ctx.drawImage(image, offsetX, offsetY, newWidth, newHeight);

        resolve(canvas.toDataURL("image/webp", 0.9));
      };

      image.onerror = () => reject(new Error("Failed to load image"));
      image.src = event.target.result;
    };

    reader.onerror = () => reject(new Error("Error reading file"));
    reader.readAsDataURL(file);
  });
}

/**
 * Converts an internal resource (e.g. /assets/images/stations/default.webp) to base64.
 * Used for MediaSession when you want a Data URL instead of a path.
 * @param {string} url - Internal extension URL (via chrome.runtime.getURL)
 * @returns {Promise<string>} - Data URL in PNG
 */
export async function toDataURL(url) {
  const response = await fetch(url); // No external network, just internal resource
  if (!response.ok) throw new Error(`HTTP error ${response.status}`);
  const blob = await response.blob();

  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result);
    reader.onerror = () => reject(new Error("Error converting to base64"));
    reader.readAsDataURL(blob);
  });
}
