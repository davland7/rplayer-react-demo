/**
 * Sends a message to the runtime and returns a promise
 * @param {string} action - Action to send
 * @param {object} params - Additional parameters
 * @returns {Promise<any>}
 */
export function sendMessage(action, params = {}) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ action, ...params }, (response) => {
      if (chrome.runtime.lastError) {
        reject(chrome.runtime.lastError);
      } else {
        resolve(response);
      }
    });
  });
}

/**
 * Wrapper to handle errors in listeners
 * @param {Function} fn - Handler function
 * @returns {Function} - Handler with error handling
 */
export function withErrorHandling(fn) {
  return (params) => {
    const action = params?.request?.action || 'unknown';

    Promise.resolve(fn(params)).catch(error => {
      console.error(`Error in action ${action}:`, error);

      if (typeof params?.sendResponse === 'function') {
        try {
          params.sendResponse({ success: false, error: error.message });
        } catch (e) {
          console.warn(`Port closed for ${action}, response impossible:`, e.message);
        }
      }
    });

    // Important to keep the port open if fn is async
    return true;
  };
}

/**
 * Gets the extension version
 * @returns {string}
 */
export function getVersion() {
  return chrome.runtime.getManifest().version;
}
