import { t } from "../utils/i18n.js";
import { sendMessage } from "../utils/extension.js";
import { ACTIONS, STATES } from "../constants/constant.js";

const stationsList = document.getElementById('stations');
const template = document.querySelector('template');
const paginationControls = document.querySelector('nav ul');
const optionsPage = document.getElementById("optionsPage");

// Configuration of player button states
const playerStateConfig = {
  [STATES.LOADING]: {
    className: 'station__play--loading',
    titleKey: 'tooltip_loading' // e.g. "Loading"
  },
  [STATES.PLAYING]: {
    className: 'station__play--pause',
    titleKey: 'tooltip_pause' // e.g. "Pause"
  },
  [STATES.PAUSED]: {
    className: 'station__play--play',
    titleKey: 'tooltip_play' // e.g. "Play"
  },
  [STATES.ERROR]: {
    className: 'station__play--play',
    titleKey: 'tooltip_play' // e.g. "Play"
  }
};
const defaultConfig = playerStateConfig[STATES.PAUSED];
// Pagination configuration
const ITEMS_PER_PAGE = 4;
let currentState = STATES.STOPPED;

/**
 * Updates the visual state of the play button
 * @param {STATES} newState - The new audio state to apply
 */
function updatePlayerButtonState(newState) {
  currentState = newState;
  const buttons = document.querySelectorAll('.station .station__play');
  const allStateClasses = Object.values(playerStateConfig).map(cfg => cfg.className);

  const config = playerStateConfig[newState];
  if (!config) return;

  for (let i = 0; i < buttons.length; i++) {
    const button = buttons[i];
    button.classList.remove(...allStateClasses);

    if (i === 0) {
      // Apply new state to active button
      button.classList.add(config.className);
      button.title = t(config.titleKey); // e.g. "Pause"
    } else {
      // Reset other buttons to default "play" state
      button.classList.add(defaultConfig.className);
      button.title = t(defaultConfig.titleKey); // e.g. "Play"
    }
  }
}

/**
 * Pagination management
 */
function createPaginationHandler(stationsList, paginationControls) {
  let currentPage = 1;
  let allListItems = [];

  function displayPage(page) {
    currentPage = page;

    const buttons = paginationControls.querySelectorAll('button');
    for (let i = 0; i < buttons.length; i++) {
      buttons[i].classList.toggle('active', parseInt(buttons[i].dataset.page) === page);
    }

    const paginatedItems = allListItems.slice(1); // Exclude the first item (currently playing)
    const startIndex = (page - 1) * ITEMS_PER_PAGE;
    const endIndex = startIndex + ITEMS_PER_PAGE;

    for (let i = 0; i < paginatedItems.length; i++) {
      const item = paginatedItems[i];
      item.style.display = (i >= startIndex && i < endIndex) ? 'grid' : 'none';
    }
  }

  function updateItemsList() {
    allListItems = Array.from(stationsList.children);
  }

  return { displayPage, updateItemsList, getCurrentPage: () => currentPage };
}

/**
 * Station list management
 */
function createStationsHandler(stationsList, template, paginationHandler) {
  async function playAndSetAsFirst(event, station) {
    const clickedItem = event.currentTarget.closest('.station');
    const isCurrentPlayer = stationsList.firstElementChild === clickedItem;

    if (isCurrentPlayer) {
      if (currentState === STATES.STOPPED || currentState === STATES.ERROR) {
        await sendMessage(ACTIONS.POPUP_PLAY_STREAM, { station });
      } else {
        await sendMessage(ACTIONS.OFFSCREEN_TOGGLE);
      }
      return;
    }

    // Move clicked item to top of list
    stationsList.prepend(clickedItem);
    paginationHandler.updateItemsList();
    paginationHandler.displayPage(paginationHandler.getCurrentPage());

    await sendMessage(ACTIONS.POPUP_PLAY_STREAM, { station });
  }

  function renderStation(station) {
    const { image, name, description } = station;
    const clone = template.content.cloneNode(true);

    clone.querySelector('.station__image').src = image;
    clone.querySelector('.station__name').textContent = name;
    clone.querySelector('.station__description').textContent = description;
    const playButton = clone.querySelector('.station__play');
    playButton.addEventListener('click', (event) => playAndSetAsFirst(event, station));
    playButton.title = t(defaultConfig.titleKey);

    return clone;
  }

  function addCustomStationButton() {
    const addStationLi = document.createElement('li');
    addStationLi.classList.add('station--custom');

    const addButton = document.createElement('button');
    addButton.textContent = t('legend_custom_station');
    addButton.addEventListener('click', () => {
      chrome.runtime.openOptionsPage();
    });

    addStationLi.appendChild(addButton);
    stationsList.appendChild(addStationLi);
  }

  return { playAndSetAsFirst, renderStation, addCustomStationButton };
}

/**
 * Handler for incoming messages from the background script
 */
function setupMessageHandler() {
  function handleMessage(message, _sender, sendResponse) {
    if (message.action === ACTIONS.OFFSCREEN_STATE_CHANGED) {
      const { state } = message;
      updatePlayerButtonState(state);
      sendResponse({ success: true });

      return true;
    }
  }

  chrome.runtime.onMessage.addListener(handleMessage);
}

/**
 * Init app
 */
(async function init() {
  try {
    const { state, stations } = await sendMessage(ACTIONS.POPUP_GET_DATA) || {};

    const paginationHandler = createPaginationHandler(stationsList, paginationControls);
    const stationsHandler = createStationsHandler(stationsList, template, paginationHandler);
    setupMessageHandler();

    for (let i = 0; i < stations.length; i++) {
      stationsList.appendChild(stationsHandler.renderStation(stations[i]));
    }
    updatePlayerButtonState(state);

    if (stations.length < 13) {
      stationsHandler.addCustomStationButton();
    }

    optionsPage.innerText = t("settings");
    optionsPage.addEventListener("click", (event) => {
      event.preventDefault();
      chrome.runtime.openOptionsPage();
    });

    // Setup pagination
    paginationHandler.updateItemsList();
    paginationControls.addEventListener('click', (event) => {
      if (event.target.tagName === 'BUTTON') {
        const page = parseInt(event.target.dataset.page);
        paginationHandler.displayPage(page);
      }
    });

    paginationHandler.displayPage(1);
  } catch (error) {
    console.error('Error initializing popup page:', error);
  }
})();
