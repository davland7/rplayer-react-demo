export const ACTIONS = Object.freeze({
  OFFSCREEN_PLAY: 'OFFSCREEN_PLAY',
  OFFSCREEN_TOGGLE: 'OFFSCREEN_TOGGLE',
  OFFSCREEN_SET_VOLUME: 'OFFSCREEN_SET_VOLUME',
  OFFSCREEN_STATE_CHANGED: 'OFFSCREEN_STATE_CHANGED',
  POPUP_GET_DATA: 'POPUP_GET_DATA',
  POPUP_PLAY_STREAM: 'POPUP_PLAY_STREAM',
  OPTIONS_GET_DATA: 'OPTIONS_GET_DATA',
  OPTIONS_SET_CUSTOM_STATION: 'OPTIONS_SET_CUSTOM_STATION',
  OPTIONS_SET_VOLUME: 'OPTIONS_SET_VOLUME',
  OPTIONS_RESET_ITEMS: 'OPTIONS_RESET_ITEMS',
  OPTIONS_PLAY_STREAM: 'OPTIONS_PLAY_STREAM'
});

export const STATES = Object.freeze({
  STOPPED: 'stopped',
  LOADING: 'loading',
  PLAYING: 'playing',
  PAUSED: 'paused',
  ERROR: 'error'
});

// Prod URL: https://mini-radio.davland7.workers.dev
// Dev URL: http://localhost:8787
export const WORKER = Object.freeze({
  URL_BASE: 'https://mini-radio.davland7.workers.dev',
  PROXY: '/proxy',
  TRACK: '/api/track',
  VALIDATE: '/validate'
});

export const VALIDATE_STATES = Object.freeze({
  PENDING: 'pending',
  VALIDATING: 'validating',
  VALID: 'valid',
  FALLBACK: 'fallback',
  INVALID: 'invalid'
});
