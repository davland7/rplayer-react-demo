import { ACTIONS, STATES, VALIDATE_STATES } from '../constants/constant.js';
import { sendMessage, getVersion } from '../utils/extension.js';
import { t } from '../utils/i18n.js';
import { fileToBase64 } from '../utils/image.js';

// Elements
const closeBtn  = document.getElementById("close");
const versionElement = document.getElementById("version");
const playPauseShortcutElement = document.getElementById("shortcut");

// Volume control
const volumeInputs = document.querySelectorAll("input[name=volume]:not(#resetVolume)");

// Custom station form elements
const customForm = document.getElementById("customForm");
const idInput = document.getElementById("id");
const nameInput = document.getElementById("name");
const descriptionInput = document.getElementById("description");
const srcInput = document.getElementById("src");
const hlsNote = document.getElementById("hls");
const fileInput = document.getElementById("file");
const imageElement = document.getElementById("image");
const saveBtn = document.getElementById("save");
const playBtn = document.getElementById("play");
const message = document.getElementById("message");

// Reset to defaults elements
const checkboxes = document.querySelectorAll('#resetOptions input[type="checkbox"]');
const resetBtn = document.getElementById("resetBtn");

// State variables
let isStationSaved = false;
let itemsToReset = [];

// Utility functions

/**
 * Set the volume radio button
 * @param {number} volume
 */
function setVolume(volume) {
  const volumeInput = document.querySelector(`input[name="volume"][value="${volume}"]`);
  if (volumeInput) volumeInput.checked = true;
}

/**
 * Set the custom station form fields
 * @param {object} station
 * @param {string} station.id
 * @param {string} station.name
 * @param {string} station.description
 * @param {string} station.src
 * @param {boolean} station.hls
 * @param {string} station.image - Base64 image string
 */
function setCustomStation(station) {
  const { id, name, description, src, hls, image, state } = station;

  idInput.value = id;
  nameInput.value = name;
  descriptionInput.value = description;
  srcInput.value = src;
  imageElement.src = image;
  hlsNote.hidden = !hls;

  const isValid = station && name && src;
  saveBtn.disabled = true; // Always disabled on load
  playBtn.disabled = !isValid;
  isStationSaved = isValid;

  // Set default form message
  updateUI(t('options_custom_station_state_' + state), state);
}

/**
 * Update the state of the reset button based on selected checkboxes
 */
function updateResetButtonState() {
  itemsToReset = [];
  checkboxes.forEach(checkbox => {
    if (checkbox.checked) itemsToReset.push(checkbox.name);
  });
  resetBtn.disabled = itemsToReset.length === 0;
}

/**
 * Update the save button state based on form validation
 */
function updateSaveButtonState() {
  const isValid = nameInput.value.trim() && srcInput.value.trim();
  saveBtn.disabled = !isValid;

  if (isStationSaved) {
    playBtn.disabled = true;
  }
}

/**
 * Update the play/pause shortcut display
 */
function updatePlayPauseShortcut() {
  chrome.commands.getAll((commands) => {
    const playpause = commands.find(command => command.name === 'playpause');
    if (!playpause) return;

    playPauseShortcutElement.textContent = `(${playpause.shortcut})`;
  });
}

// Event listeners

closeBtn.addEventListener('click', () => window.close());

nameInput.addEventListener('input', updateSaveButtonState);
descriptionInput.addEventListener('input', updateSaveButtonState);
srcInput.addEventListener('input', updateSaveButtonState);

/**
 * Volume control
 */
volumeInputs.forEach(input => {
  input.title = `${100 * Number(input.value)}%`;
  input.addEventListener('change', async event => {
    const volume = Number(event.target.value);
    await sendMessage(ACTIONS.OPTIONS_SET_VOLUME, { volume });
  });
});

/**
 * File input change handler
 */
fileInput.addEventListener('change', async () => {
  if (fileInput.files.length > 0) {
    const base64 = await fileToBase64(fileInput.files[0]);
    imageElement.src = base64;
    updateSaveButtonState();
  }
});

/**
 * Save the custom station
 */
customForm.addEventListener("submit", async (event) => {
  event.preventDefault();

  const station = {
    id: Number(idInput.value),
    name: nameInput.value.trim(),
    description: descriptionInput.value.trim(),
    src: srcInput.value.trim(),
    hls: !hlsNote.hidden,
    image: imageElement.src,
    state: VALIDATE_STATES.PENDING
  };

  // Url validation basic check
  if (!station.src.startsWith("https://")) {
    updateUI(t('options_custom_station_state_invalid'), VALIDATE_STATES.INVALID);
    return;
  }

  try {
    updateUI(t('options_custom_station_state_validating'), VALIDATE_STATES.VALIDATING);

    const result = await sendMessage(ACTIONS.OPTIONS_SET_CUSTOM_STATION, { station });
    const { state, hls } = result.station;

    saveBtn.disabled = true;
    hlsNote.hidden = !hls;

    if (state === VALIDATE_STATES.VALID || state === VALIDATE_STATES.FALLBACK) {
      updateUI(t('options_custom_station_state_' + state), state);
      playBtn.disabled = false;
      isStationSaved = true;
    } else if (state === VALIDATE_STATES.INVALID) {
      updateUI(t('options_custom_station_state_invalid'), VALIDATE_STATES.INVALID);
      playBtn.disabled = true;
      isStationSaved = true; // Vérifer a quoi cela sert
    }
  } catch (error) {
    console.error('[Options] Custom station save failed:', error);
    updateUI(t('options_custom_station_state_fallback'), VALIDATE_STATES.FALLBACK);
    playBtn.disabled = true;
    isStationSaved = false;
  }
});

/** Update the form message and class
 * @param {string} text
 * @param {string} validateClass
 */
function updateUI(text, validateClass = VALIDATE_STATES.PENDING) {
  message.innerText = text;
  message.className = validateClass;
};

/**
 * Play the custom station
 */
playBtn.addEventListener('click', async () => {
  sendMessage(ACTIONS.OPTIONS_PLAY_STREAM, {
    station: {
      id: Number(idInput.value),
      name: nameInput.value,
      description: descriptionInput.value,
      src: srcInput.value,
      image: imageElement.src
    }
  });
});

/**
 * Reset checkboxes change handler
 */
checkboxes.forEach(checkbox => {
  checkbox.addEventListener("change", updateResetButtonState);
});

/**
 * Reset button click handler
 */
resetBtn.addEventListener('click', async () => {
  try {
    const itemsList = itemsToReset.map(item => '– ' + t('options_reset_label_' + item)).join('\n');
    const confirmationMessage = t('options_reset_confirm', [itemsList]);

    if (!confirm(confirmationMessage)) {
      return;
    }

    resetBtn.disabled = true;
    checkboxes.forEach(checkbox => checkbox.checked = false);

    const { results, success } = await sendMessage(ACTIONS.OPTIONS_RESET_ITEMS, { items: itemsToReset });

    if (!success) {
      throw new Error('Reset action failed');
    }

    // Apply changes to the UI
    const { volume, custom_station: customStation } = results;

    if (volume !== undefined) setVolume(volume);
    if (customStation !== undefined) setCustomStation(customStation);
  } catch (error) {
    console.error('[Options] Reset failed:', error);
    // Restore checkbox states on error
    itemsToReset.forEach(item => {
      const checkbox = document.querySelector(`input[name="${item}"]`);
      if (checkbox) checkbox.checked = true;
    });
  } finally {
    updateResetButtonState();
  }
});

// Initialization

try {
  // Internationalization
  document.querySelectorAll('[data-i18n]').forEach(element => {
    element.textContent = t(element.dataset.i18n);
  });

  // Set version
  versionElement.textContent = getVersion();

  // Set placeholders
  nameInput.setAttribute('placeholder', t('options_custom_station_placeholder_name'));
  srcInput.setAttribute('placeholder', t('options_custom_station_placeholder_src'));

  // Load data
  const { station, volume } = await sendMessage(ACTIONS.OPTIONS_GET_DATA);

  setVolume(volume);
  setCustomStation(station);
  updateResetButtonState();
  updatePlayPauseShortcut();
} catch (error) {
  console.error('[Options] Critical: Initialization failed:', error);
}
