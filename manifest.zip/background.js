let errors = [];       // Erreurs en mémoire vive
let attachedTabId = null;

function setIcon(state) {
  const iconPath = state === "on" ? {
    "16": "coccinelle-on.png",
    "48": "coccinelle-on.png",
    "128": "coccinelle-on.png"
  } : {
    "16": "coccinelle-off.png",
    "48": "coccinelle-off.png",
    "128": "coccinelle-off.png"
  };
  chrome.action.setIcon({ path: iconPath });
}

function pushError(error) {
  errors.push(error);
  chrome.runtime.sendMessage({ type: "NEW_ERROR", errors }).catch(() => {});
  setIcon("on");
}

chrome.action.onClicked.addListener((tab) => {
  chrome.sidePanel.open({ windowId: tab.windowId });
  chrome.debugger.attach({ tabId: tab.id }, "1.3", () => {
    if (chrome.runtime.lastError) {
      console.error("Erreur attach debugger:", chrome.runtime.lastError.message);
      return;
    }
    chrome.debugger.sendCommand({ tabId: tab.id }, "Network.enable");
    chrome.runtime.sendMessage({ type: "DEBUGGER_ATTACHED", tabId: tab.id }).catch(() => {});
  });
  attachedTabId = tab.id;

  chrome.debugger.onEvent.addListener((source, method, params) => {
    if (method === "Network.loadingFailed") {
      pushError({
        kind: "network",
        message: params.errorText,
        source: params.url || params.requestId,
        resourceType: params.type,
        timestamp: Date.now()
      });
    }
  });
});

// Reset quand on change d’onglet
chrome.tabs.onActivated.addListener((activeInfo) => {
  errors = [];
  setIcon("off");
  chrome.runtime.sendMessage({ type: "TAB_CHANGED", tabId: activeInfo.tabId }).catch(() => {});
});

// Erreurs JS envoyées par content.js
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "JS_ERROR" && msg.payload) {
    pushError(msg.payload);
  }
});