const errorListEl = document.getElementById("errorList");
const outputEl = document.getElementById("output");
const analyzeBtn = document.getElementById("analyzeBtn");
const badgeEl = document.getElementById("badge");
const apiKeyInput = document.getElementById("apiKeyInput");
const promptInput = document.getElementById("promptInput");
const modelSelect = document.getElementById("modelSelect");
const saveSettingsBtn = document.getElementById("saveSettingsBtn");
const resetBtn = document.getElementById("resetBtn");
const debuggerStatusEl = document.getElementById("debuggerStatus");

// Badge onglet actif
const tabBadgeEl = document.createElement("div");
tabBadgeEl.id = "tabBadge";
tabBadgeEl.style.marginTop = "6px";
tabBadgeEl.style.fontSize = "12px";
tabBadgeEl.style.fontWeight = "bold";
tabBadgeEl.style.color = "#3498db";
document.body.insertBefore(tabBadgeEl, document.getElementById("settings"));

const DEFAULT_PROMPT = promptInput.value.trim();

function setBadge(color) {
  badgeEl.className = `badge badge-${color}`;
}

// Rendu multi-erreurs
function renderErrors(errors) {
  if (!Array.isArray(errors) || errors.length === 0) {
    errorListEl.textContent = "Aucune erreur détectée pour l’instant.";
    setBadge("red");
    return;
  }

  errorListEl.innerHTML = ""; // reset

  errors.forEach((err, index) => {
    const details = document.createElement("details");
    details.className = err.kind === "network" ? "network-error" : "js-error";

    const summary = document.createElement("summary");
    summary.textContent = `Erreur ${index + 1}: ${err.message}`;
    details.appendChild(summary);

    const info = document.createElement("pre");
    if (err.kind === "network") {
      info.textContent = `Type: ${err.resourceType}\nURL: ${err.source}\nMessage: ${err.message}`;
    } else {
      const src = err.source || "unknown";
      const loc = `${src}:${err.line || 0}:${err.column || 0}`;
      info.textContent = `${err.message}\n(${loc})`;
    }
    details.appendChild(info);

    const btn = document.createElement("button");
    btn.textContent = "Analyser avec AI";
    btn.addEventListener("click", async () => {
      outputEl.textContent = "Analyse en cours…";
      setBadge("yellow");
      const prompt = buildPrompt(err);
      try {
        const explanation = await callCopilot(apiKeyInput.value.trim(), modelSelect.value, prompt);
        outputEl.textContent = explanation || "Aucune réponse de l'API.";
        setBadge("green");
      } catch (e) {
        outputEl.textContent = `Erreur API: ${e.message}`;
        setBadge("red");
      }
    });
    details.appendChild(btn);

    errorListEl.appendChild(details);
  });
}

// Prompt builder
function buildPrompt(err) {
  const basePrompt = promptInput.value.trim() || DEFAULT_PROMPT;
  const stack = err.stack ? `\nStack:\n${err.stack}` : "";
  return `${basePrompt}\n\nErreur: """${err.message}"""\nContexte: fichier ${err.source} ligne ${err.line} colonne ${err.column}${stack}`;
}

// Appel API Copilot Entreprise uniquement
async function callCopilot(apiKey, model, prompt) {
  if (!apiKey) {
    return `FAKE Copilot (${model}):\nAnalyse de "${prompt}"\n\nExemple: Cette erreur est due à une ressource annulée.`;
  }

  const endpoint = `https://api.microsoftcopilot.com/v1/models/${model}/invoke`;
  const res = await fetch(endpoint, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`
    },
    body: JSON.stringify({ input: prompt })
  });

  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Copilot API error ${res.status}: ${text.slice(0,100)}...`);
  }

  const json = await res.json();
  return json.output || JSON.stringify(json);
}

// Boutons
analyzeBtn.addEventListener("click", () => {
  outputEl.textContent = "⚠️ Rafraîchissement manuel non nécessaire en mode mémoire.";
});

saveSettingsBtn.addEventListener("click", () => {
  outputEl.textContent = "⚙️ Paramètres enregistrés pour Copilot Entreprise.";
});

resetBtn.addEventListener("click", () => {
  promptInput.value = DEFAULT_PROMPT;
  outputEl.textContent = "Prompt réinitialisé par défaut.";
});

// écoute messages
chrome.runtime.onMessage.addListener((msg) => {
  if (msg?.type === "NEW_ERROR") {
    renderErrors(msg.errors || []);
  }
  if (msg?.type === "TAB_CHANGED") {
    errorListEl.textContent = "Nouvel onglet actif → aucune erreur pour l’instant.";
    setBadge("red");
    tabBadgeEl.textContent = `📑 Onglet actif #${msg.tabId}`;
  }
  if (msg?.type === "DEBUGGER_ATTACHED") {
    debuggerStatusEl.textContent = "🐞 Debugger actif sur cet onglet";
    debuggerStatusEl.style.color = "#e67e22";
  }
  if (msg?.type === "DEBUGGER_DETACHED") {
    debuggerStatusEl.textContent = "🐞 Debugger détaché";
    debuggerStatusEl.style.color = "#2ecc71";
  }
});