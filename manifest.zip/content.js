// Injecte le script externe dans la page (évite CSP inline)
(function inject() {
  const script = document.createElement("script");
  script.src = chrome.runtime.getURL("inject-page-listener.js");
  (document.head || document.documentElement).appendChild(script);
})();

// Relai des messages vers background.js
window.addEventListener("message", (event) => {
  if (!event.data || event.data.source !== "BUGBUDDY_PAGE") return;
  const p = event.data.payload;
  const normalized = {
    message: p.message,
    source: p.source || location.href,
    line: p.line || 0,
    column: p.column || 0,
    stack: p.stack || null,
    kind: p.kind || "console",
    level: p.level || null,
    timestamp: p.timestamp || Date.now()
  };
  chrome.runtime.sendMessage({ type: "JS_ERROR", payload: normalized });
});

// Reset quand la page est rechargée
chrome.runtime.sendMessage({ type: "PAGE_LOADED" });