(function () {
  function send(payload) {
    window.postMessage({ source: "BUGBUDDY_PAGE", payload }, "*");
  }

  // Erreurs JS classiques
  window.addEventListener("error", (e) => {
    send({
      kind: "error",
      message: e.message || "Unknown error",
      source: e.filename || location.href,
      line: e.lineno || 0,
      column: e.colno || 0,
      stack: e.error?.stack || null,
      timestamp: Date.now()
    });
  });

  // Promesses non gérées
  window.addEventListener("unhandledrejection", (e) => {
    const reason = e.reason;
    send({
      kind: "unhandledrejection",
      message: (reason && reason.message) || String(reason) || "Unhandled rejection",
      source: "Promise",
      stack: reason?.stack || null,
      timestamp: Date.now()
    });
  });

  // Override console.error
  const origError = console.error;
  console.error = function (...args) {
    send({
      kind: "console",
      level: "error",
      message: args.map(a => (typeof a === "string" ? a : (a?.message || JSON.stringify(a)))).join(" "),
      raw: args,
      timestamp: Date.now()
    });
    origError.apply(console, args);
  };

  // Override console.warn
  const origWarn = console.warn;
  console.warn = function (...args) {
    send({
      kind: "console",
      level: "warn",
      message: args.map(a => (typeof a === "string" ? a : (a?.message || JSON.stringify(a)))).join(" "),
      raw: args,
      timestamp: Date.now()
    });
    origWarn.apply(console, args);
  };
})();